#!/usr/bin/perl
use 5.006;
use strict;
use warnings;
use Config::IniFiles;
use File::Basename;
use Data::Dumper;
use DBI;
use POSIX qw/strftime/;
use Getopt::Long;
use Term::ShellUI;
use Text::TabularDisplay;

our $VERSION = '0.16';

my ($help, @exec);
my $config = "/etc/voiceng/voip_db_active.ini";  # путь по-умолчанию, если необходимо изменить, можно передать через параметр --config
my ($dbh, $db_host, $db_user, $db_pass);

usage() if ( ! GetOptions('help|?' => \$help, 'exec=s{2,3}' => \@exec, 'config=s' => \$config)
          or defined $help );
@exec = split(/,/,join(',',@exec));

# вывод справки при неправильном наборе команд
sub usage
{
  print "Unknown option: @_\n" if ( @_ );
  print "usage: voicectl [--exec команда] [--config путь_до_конфига] [--help|-?]\n";
  exit;
}

# подгрузка конфига
sub LoadConfigFile 
{   
    if (-e $config) {
        my $cfg = Config::IniFiles->new( -file => $config );
        $db_host = $cfg->val('mysql-db', "db_host");        
        $db_user = $cfg->val('mysql-db', "db_user");
        $db_pass = $cfg->val('mysql-db', "db_password"); 
    }
    else {
        print "[FAILED] отсутствует файл с настройками подключения к БД\n";
    }
}

# команды оболочки
sub get_commands
{
    return {
        "h" =>    { alias => "help", exclude_from_completion => 1 },
        "?" =>    { alias => "help", exclude_from_completion =>1 },
        "help" => {
            desc => "Помощь",
            args => sub { shift->help_args(undef, @_); },
            method => sub { shift->help_call(undef, @_); }
            },
        "history" => {
            desc => "Команда для вывода истории команд",
            doc => " [number] Укажите число, чтобы вывести последние N строк истории\n" .
              " -c очистка всей истории\n" .
              " -d НОМЕР удалить единственную запись\n",
            args => "[-c] [-d] [number]",
            method => sub { shift->history_call(@_) },            
          },
          "quit" => { alias => "exit", exclude_from_completion => 1 },
          "exit" => {
            desc => "Выйти из программы",
            maxargs => 0,
            method => sub { shift->exit_requested(1); },
          },
          "show" => {
              desc => "Команда для вывода информации о скриптах",
              doc  => " Команда имеет следующие параметры:\n" .
                      "  all вывод всей доступной информации о скриптах\n" .
                      "  node вывод скриптов запущенных на указаной ноде\n",
              cmds => {
                  "all" => {
                      desc => "Вывод информации по скриптам",
                      method => sub {
                          my $self = shift;
                          my $parms = shift;
                          &showScripts('all');
                      },                  
                  },                  
                  "node" => {                    
                      desc => "Вывод информации по скриптам на выбранной ноде",
                      method => sub { 
                        my $self = shift;
                        my $parms = shift;
                        my $data = $parms->{'args'}[0]; #берем первый параметр(выбранная нода)
                        &showScripts('node', $data);
                      },
                  },
                  "script" => {
                      desc => "Вывод информации по выбранному скрипту",
                      method => sub { 
                        my $self = shift;
                        my $parms = shift;
                        my $data = $parms->{'args'}[0]; #берем первый параметр(выбранный скрипт)
                        &showScripts('script', $data);
                      }, 
                  },                  
              },              
          },
          "change" => {
              desc => "Команда для управления",
              doc => " Команда имеет следующие параметры:\n".
                      " role имя_скрипт - перенести Master роль на другую ноду\n".
                      " role all - сменить роли для всех скриптов\n",
              cmds => {
                  "role" => {
                      desc => "команда изменения ролей",
                      method => sub {
                          my $self = shift;
                          my $parms = shift;
                          my $data = $parms->{'args'}[0]; #берем первый параметр(выбранный скрипт)
                          if (defined $data ) {
                            &changeRole($data);
                          }
                          else {
                              print "[FAILED] Не указано имя скрипта или параметр all для изменения всех скриптов\n";
                          }
                          
                      },
                  },
              },
          },          
    };
}

sub _mysql_connect
{
    $dbh = DBI->connect("DBI:mysql:database=voiceng;host=$db_host;port=3306",
                              $db_user, $db_pass,
                              {
                                'RaiseError'        => 1,
                                'InactiveDestroy'   => 1,
                              }
        );
   
    $dbh->{mysql_auto_reconnect} = 1;
    return 1;
}

sub showScripts
{
    my ($terms, $data) = @_;
    my @row;    
    my $connectResult = &_mysql_connect(); 
    if (defined $connectResult) {
        my @columns = ('Name', 'Path', 'Server', 'Role', 'Next_run', 'Every_hour', 'controltime');
        my $table = Text::TabularDisplay->new(@columns);
        my $sth;
        
        eval {
          if ($terms eq 'all') {
              $sth = $dbh->prepare('SELECT script_name, full_path, node, status, time_change_role, time_repeat_change, controltime FROM `scripts_dispatcher`');
              $sth->execute();
          }          
          elsif ($terms eq 'node') {              
              $sth = $dbh->prepare("SELECT script_name, full_path, node, status, time_change_role, time_repeat_change, controltime FROM `scripts_dispatcher` WHERE node = ?");
              $sth->execute($data);
          }
          elsif ($terms eq 'script') {
              $sth = $dbh->prepare("SELECT script_name, full_path, node, status, time_change_role, time_repeat_change, controltime FROM `scripts_dispatcher` WHERE script_name LIKE ?");
              $sth->execute("%".$data."%");
          }

        };      
        
        if ($@) {
          print "[FAILED] Произошла ошибка при разборе запроса или его выполнение: $sth->errstr";
          return undef;
        }

        while(@row = $sth -> fetchrow_array) {
          $table->add(@row);
        }
        print $table->render;
        print "\n";
        $sth->finish();
        $dbh->disconnect();
    }
    else {
      print "[FAILED] Запрос не обработан. Невозможно подключиться к БД.\n";
    }

}

sub changeRole 
{
    my $script_name = shift;
    my $connectResult = &_mysql_connect(); 
    if (defined $connectResult) {
        eval {
            if ($script_name eq 'all') {
                $dbh->do("UPDATE scripts_dispatcher SET time_change_role = NOW()", undef); 
            } 
            else {
                $dbh->do("UPDATE scripts_dispatcher SET time_change_role = NOW() WHERE script_name = ?", undef, $script_name);
            }
            $dbh->disconnect();
        };
        if ($@) {
          print "[FAILED] Ошибка выполнения запроса\n";
          $dbh->disconnect();
          return undef;
        }        
    }
    else {
        print "[FAILED] Запрос не обработан. Невозможно подключиться к БД.\n";
    }
}

&LoadConfigFile();

if (defined $exec[0]) {
  
  if ($exec[0] eq 'show') {
      if ($exec[1] eq 'all') {
          &showScripts('all','');
      }
      elsif ($exec[1] eq 'node') {
          &showScripts('node', $exec[2]);
      }
      elsif ($exec[1] eq 'script') {
          &showScripts('script', $exec[2]);
      } 
      else {
          print "[FAILED] Неверный аргумент команды, используйте all, node [имя_сервера], script [имя_скрипта]\n";
      }
  }
  elsif ($exec[0] eq 'change') {
      if ($exec[1] eq 'role') {
        if (defined $exec[2]) {
            if ($exec[2] eq 'all') {
                &changeRole('all'); 
            } else {
                &changeRole($exec[2]);
            }
        }
        else {
            print "[FAILED] Неверный аргумент команды, используйете change role [all|имя_скрипта]\n";
        }
      }
      else {
          print "[FAILED] Неверный аргумент команды, используйете role [all|имя_скрипта]\n";
      }
  }
  else {
    print "[FAILED] Введена некорректная команда, используйете show или change\n";
  }

}
else {
  # создание интерфейса
  my $term = new Term::ShellUI(
    commands => get_commands(),
    history_file => '~/.voicectl-history',
  );

  $term->prompt(['voicectl:~$ ', '>']);
  $term->run();
}