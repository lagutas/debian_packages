=pod Описание

	Balancer - Класс для балансировки скриптов
	Автор: Гостьков Евгений 
	RT: 146048
	
	Если имя функции начинается с символа "_", то это внутренний метод, используется исключительно внтури класса.
	

	P.S. Установка модулей, все модули содержаться в стандартном репозитории debian, кроме use Log::Any::Adapter::Log4Perl, его поставил из jessie.
		Установка: 
				1) в файле /etc/apt/apt.conf.d/70debconf gрописываем APT::Default-Release "stable";
				2) /etc/apt/sources.list добавляем deb http://ftp.debian.org/debian jessie main contrib non-free
				3) apt-get update
				4) apt-get install liblog-any-adapter-log4perl-perl
=cut

package Voiceng::Balancer;

use 5.006;
use strict;
use warnings;

use Config::IniFiles;
use Cwd;
use Data::Dumper;
use DBI;
use File::Basename;
use File::stat;
use Socket;
use IO::Socket::INET;
use IO::Select;
use JSON;
use POSIX qw(strftime);
use Log::Any;
use Log::Any::Adapter;
use Log::Log4perl qw(:easy);
Log::Any::Adapter->set('Log4perl');
use Term::ANSIColor;
use Socket;
use Sys::Hostname;
use Sys::Syslog;
use Time::localtime qw();
use Time::Piece;

our $VERSION = '0.20';
=pod История изменений

	0.1 - базовая версия
	0.15 - Правка багов, добавление voicectl
	0.16 - Поправка багов с mysql
	0.20 - Переделка на асинхронную работу
=cut

my ($db_host, $db_user, $db_password);	#глобальные переменные для работы с БД
my $currentScriptName;					# имя текущего скрипта ьез расширения .pl
my $currentScriptNameWithExtension;		# имя текущего скрипт с расширением
my $dbh;								# хэндлер БД
my $log;				
my $currentDir;							# текущая директория
my $timestampDBconfig = 1399461353;		# timestamp времени изменения файл /etc/voiceng/voip_db_active.ini
my $pathToDBactive = '/etc/voiceng/voip_db_active.ini';
my $parentPid;
my $childrenPid;

# конструктор
sub new
{
    my $class = shift;
    my $mode = shift;		# передаем скрипту debug для уровня отладки DEBUG
	my $self;

    $currentDir = getcwd();
    $currentScriptName = basename($0);			#получаем имя запускаемого скрипта
    $currentScriptNameWithExtension = $currentScriptName;	# имя скрипта полносью
	$currentScriptName = substr($currentScriptName, 0, -3);	#отрезаем .pl

    my $pathsToSearchConfigFile = "/etc/voiceng/${currentScriptName}.ini"; # хранения конфигруационного файла скрипта    
    my @parameters = ('local_address', 'local_port', 'neightbour_address', 'neightbour_port'); # массив содержаший обязательные параметры из ini файла
	my $lenParamaters = @parameters;
	my %parametersFromIniFile = ();

	if ($mode eq "debug") {
    	Log::Log4perl->easy_init(
		{	
			level  => 'DEBUG', 
			file   => '>>'."/var/log/voiceng/${currentScriptName}-balancer.log",
			layout => "%d %r ms [%P] %p: %m%n",
		}
		);
		$log = Log::Any->get_logger();
    }
    else {
    	Log::Log4perl->easy_init(
		{	
			level  => 'INFO', 
			file   => '>>'."/var/log/voiceng/${currentScriptName}-balancer.log",
			layout => "%d %r ms [%P] %p: %m%n",
		}
		);
		$log = Log::Any->get_logger();
    }
	
	# проверяем существуют ли конфигурационные файлы
	my $temp;
	eval {
		my $cfg = Config::IniFiles->new( -file => $pathsToSearchConfigFile );
		  	
    	for (my $i = 0; $i < $lenParamaters; $i++) {
    		if ($cfg->val( $currentScriptName, $parameters[$i] )) {    		
    			$temp = $cfg->val( $currentScriptName, $parameters[$i] );
    			$parametersFromIniFile{$parameters[$i]} = $temp;
    		} else {
    			#завершаем работу если в конфиг файле нет обязательных параметров (массив parameters)
    			$log->error("В файле отсутствуют обязательные параметры: $parameters[$i] ");
    			exit;
    		}
    	}    		

    	$self = {
    		_local_address	=> $parametersFromIniFile{'local_address'},
    		_local_port		=> $parametersFromIniFile{'local_port'},
    		_neightbour_address => $parametersFromIniFile{'neightbour_address'},
    		_neightbour_port	=> $parametersFromIniFile{'neightbour_port'},  	
 		}; 		
    };
	if ($@) {
		print "Отсутствует конфигруационный файл, создать его?(Y/n): ";	
		chomp (my $input = <STDIN>);
		$input ||= "y";
		if (($input eq 'y') || ($input eq 'Y')) {
			&initNewScript();
		}
		else {
			print "Конфигурационный файл отсутствует. Закрываюсь.";
			$log->error("Конфигурационный файл отсутствует. Закрываюсь.");
		}
	}
		
 	&_checkTimestampDBconfig();	# читаем конфиг настроек соединения с БД
	&_mysqlConnect();

    bless $self, $class;
    return $self;
}

# функция провереяет изменился ли файл настроек
sub _checkTimestampDBconfig {
	
	if (-e $pathToDBactive ) {
		my $fh = $pathToDBactive;
		my $epoch_timestamp = stat($fh)->mtime;
	
		#$log->debug("Timestamp $fh: $epoch_timestamp \n");
		#$log->debug("Timestamp in script: $timestampDBconfig \n");	
		
		if ($epoch_timestamp != $timestampDBconfig) {
			my $cfg_db = Config::IniFiles->new( -file => $pathToDBactive );
	
			$db_host = $cfg_db->val('mysql-db', 'db_host');
			$db_user = $cfg_db->val('mysql-db', 'db_user');
			$db_password = $cfg_db->val('mysql-db', 'db_password');
			#$log->info("Примeнение настроек соединения с БД: хост: $db_host, юзер: $db_user, пароль: $db_password ");
			$timestampDBconfig = $epoch_timestamp;
			
			if( defined($dbh) ) {
     				$dbh->disconnect();
			}
			&_mysqlConnect();		
		} else {
			$log->debug("Настройки соединения с БД не изменялись");
		}	
	}	
	else {
		$log->error("Отсутствует файл настроек подключения к БД: $pathToDBactive");
		print "[FAILED] Отсутствует файл настроек подключения к БД: $pathToDBactive";
		exit;
	}

}

sub  _mysqlConnect
{
	eval
    {
        $dbh = DBI->connect
        (
            "DBI:mysql:voiceng;host=$db_host", $db_user, $db_password,
                {
                    'RaiseError'        => 1,
                    'InactiveDestroy'   => 1,
                }
        );
    };

    if ($@)
    {
		$log->error("Не удалось подключиться к БД (error: '%s')", $DBI::errstr);
		return undef;
    }

    $dbh->{mysql_auto_reconnect} = 1;
    return 1;
}

# функция возращает время смены ролей из БД для текущего скрипта
sub _getTimeToChangeRole
{
	&_checkTimestampDBconfig();
	
	if( !defined($dbh) ) {
        &_mysqlConnect();
    }
  
	my $sth;
	eval {
		$sth = $dbh->prepare("SELECT time_change_role FROM `scripts_dispatcher` WHERE script_name = ? LIMIT 1");
	};
	if ($@) {
		$log->error("Произошла ошибка при разборе запроса #1 (error: %s)", $DBI::errstr);
		$sth->finish();
		return undef;
	}

	eval {
		$sth->execute($currentScriptNameWithExtension) 
	};
	if ($@) {
		$log->error("Произошла ошибка при выполнение запроса: $sth->errstr");
		$sth->finish();
		return undef;
	}
	
	my $data = $sth->fetchrow_array();
	if (defined $data) {
		$sth->finish();
		return $data;
	}
	else {
		$log->warn("Время смены ролей не задано");
		$sth->finish();
		return undef;
	}
}

sub _updateTimeChangeRole
{
	&_checkTimestampDBconfig();
	if( !defined($dbh) ) {
        &_mysqlConnect();
    }
    my $sth;

	eval {
		$sth = $dbh->prepare('SELECT time_repeat_change FROM `scripts_dispatcher` WHERE script_name = ? LIMIT 1')
	};
	if ($@) {
		$log->error("Произошла ошибка при разборе запроса #1 (error: %s)", $DBI::errstr);
		return undef;
	}
	
	eval {
		$sth->execute($currentScriptNameWithExtension);
	};
	if ($@) {
		$log->error("Произошла ошибка при выполнение запроса: $sth->errstr");
		return undef;
	}
	 				
	my $data;
	$data = $sth->fetchrow_array();

	if (defined $data) {
		$log->debug("Получен интервал обновления: " . $data);
	}
	else {
		$data = 24;
		$log->warn("Интервал обновления не задан, использую по-умолчанию $data часа");
	}
	$sth->finish();

	#Пробуем задать новое время для изменения роли
	eval {
		my $host = `hostname`;
		chomp($host);
		my $currentTime = strftime('%Y-%m-%d %H:%M:%S',localtime);
		$dbh->do("UPDATE scripts_dispatcher SET time_change_role = NOW() + INTERVAL ? HOUR WHERE script_name = ?", undef, $data, $currentScriptNameWithExtension);
	};
	if ($@) {
		$log->error("Не удалось задать время следующей смены ролей.");
		return undef;
	}	
}

# функция для принятия решения о смене ролей.
sub _checkTimeChangeRole
{
	
	my $timeFromDB = &_getTimeToChangeRole(); # получаем время для смены ролей скрипта, в случае не успкеха возвращаем undef
	if (defined $timeFromDB) {
		#2014-04-25 11:58:25
		chomp($timeFromDB);
		my $t = Time::Piece->strptime($timeFromDB,"%Y-%m-%d %H:%M:%S");
		my $unixTimeFromDB = $t->epoch;		
		
		my $currentDatetime = `date +"%Y-%m-%d %H:%M:%S"`;
		chomp($currentDatetime);
		$t = Time::Piece->strptime($currentDatetime,"%Y-%m-%d %H:%M:%S");

		my $unixCurrentDatetime = $t->epoch;
		my $diff = scalar($unixTimeFromDB-$unixCurrentDatetime);
		$log->debug("Разница во времени: $diff ");
		if ($diff < 60) {
			$log->warn("Разница менее 60 сек., необходимо меняться ролями");
			return 0;	
		}
		elsif ($diff >= 60)
		{
			$log->debug("Разница во времени более 60 сек, еще рано меняться ролями");
			return undef;
		}
		return undef;			
	}
	else {
		$log->warn("Невозможно принять решение о смене ролей, т.к. время в базе не установлено");
		return undef;
	}
}

sub _dbSetRole
{	
	my $role = shift;
	
	if ($role eq "master" || $role eq "slave") {
		&_checkTimestampDBconfig();
		if( !defined($dbh) ) {
     	   &_mysqlConnect();
    	}
		eval {
			my $host = `hostname`;
			chomp($host);
			my $currentTime = strftime('%Y-%m-%d %H:%M:%S',localtime);
			my $result = $dbh->do("UPDATE scripts_dispatcher SET status = ?, controltime = ? WHERE script_name = ? AND node = ?", undef, $role, $currentTime, $currentScriptNameWithExtension, $host);			
			if ($result eq "0E0") {
				$log->error("Не удалось установить $role роль в БД, т.к. нет информации о скрипте в таблице");
				exit;
			}		
		};
		if ($@) {
			$log->error("Возникла ошибка обновления записи. Не удалось установить $role роль в базе");	
			exit;	
		}		
	}
	else {
		$log->error("Установка статуса скрипта. Передан не верный параметр: $role ");
		exit;
	}
	
}

sub _readFromSocket
{
	my $sock = shift;
	my $data;
    $sock->recv($data, 1024);
    #sysread($sock, $data, 1024);
    $log->debug("Полученные данные: $data");

    #декодируем json запрос
    my $received_data = decode_json($data);
	my $temp_value = $$received_data{'query'};
	return $temp_value;
}

sub _keepaliveServer 
{
	my $local_ip = shift;
	my $local_port = shift;
	my $parent_pid = getppid();
	my $exit_from_while = "false";

	$parentPid = $parent_pid;
	kill 12, $parent_pid;	# отправляем сигнал родительскому процессу	
	$log->info("Переход в режим Master-скрипта. Слушаю: $local_ip:$local_port");	
	&_dbSetRole('master');
	
	my $listen_socket = new IO::Socket::INET (
   			LocalHost => $local_ip,
   			LocalPort => $local_port,
   			Proto => 'tcp',
   			Listen => 5,
   			Reuse => 1
		);
	$log->info("Переход в режим Master-скрипта. Сокет-сервер успешно запущен");	
	
	my $readers = IO::Select->new();
	$readers->add($listen_socket);

	while(1)
	{
		if ($exit_from_while eq "true") {
			last;
		}

		&_dbSetRole('master');

		if(!-e "/proc/$parentPid")
		{
			$log->error("Родительский процесс $currentScriptName не запущен, завершаем процесс Master");
			exit;
		}		

		my @ready = $readers->can_read(1);

		for my $handle(@ready)
    	{    		
    		if($handle eq $listen_socket)
        	{
            	my($client);
            	my $connect = $listen_socket->accept();
            	my $client_address = $connect->peerhost();
    			my $client_port = $connect->peerport();
    			$log->debug("Соединение от $client_address:$client_port");
           		$readers->add($connect);
        	}         
        	# existing client read
        	else
        	{
        		my $user_input;
        		sysread($handle, $user_input, 1024);
        		#декодируем json запрос
    			my $received_data = decode_json($user_input);
    			my $temp_value = $$received_data{'query'};

				if ($temp_value eq "changerole")
				{			
					#сначала проверяем время, возможно ли смениться ролями. (_checkTimeChangeRole)
					#затем пробуем сделать update времени следующей смены ролей, если удалость сделать апдейт, то меняемся ролями(_updateTimeChangeRole)			

					my $temp_check_role_result = &_checkTimeChangeRole();
					if (defined $temp_check_role_result) {
						my $temp_check_update_result = &_updateTimeChangeRole();
						if (defined $temp_check_update_result) {
							#отсылаем согласие о смене ролей
							$log->info("Передача Master-роли");
							my %query = ('query' => 'changerole_accepted');
							my $json_request = encode_json(\%query);			
							send($handle, $json_request, 0);
							shutdown($handle,1);
							$readers->remove($handle);
							close $handle;		
							$log->info("Беру роль Slave-скрипта");
							kill 10, $parent_pid;	# Отсылаем сигнал sigusr1 для приостановления				
							sleep(10);
							$exit_from_while = "true";
							last;
						}
						else {
							$log->error("Невозможно сменить роли, т.к. не выполнен update даты следующего изменения");
						}
					}
					else {
						$log->debug("Еще рано меняться ролями");
						my %query = ('query' => 'changerole_rejected');
						my $json_request = encode_json(\%query);			
						syswrite($handle, $json_request);
						$readers->remove($handle);
						close $handle;								
					}		
			
 				}
            	
        	}
    	}
   		sleep(2);  		
	}
		#$socket->close();

}#end sub


#метод проверки соседа
sub _checkNeightbour 
{
	my $neightbour_ip = shift;
	my $neightbour_port = shift;

	$log->debug("Проверка доступности соседа $neightbour_ip:$neightbour_port");
	my $socket = new IO::Socket::INET (
		PeerHost	=> $neightbour_ip,
		PeerPort	=> $neightbour_port,
		Proto		=> 'tcp',
	) or return 1; #"Сосед недоступен. $self->{_neightbour_address}:$self->{_neightbour_port} \n";

	my %query = ('query' => 'changerole');
	my $json_request = encode_json(\%query);

	$socket->send($json_request);
	
	my $temp_value = &_readFromSocket($socket);
 	if ($temp_value eq "changerole_accepted")
 	{
 		$log->info("Получено разрешение на смену ролей");
 		shutdown($socket,1);
 		$socket->close();
 		return 1;
 	}
 	elsif ($temp_value eq "changerole_rejected")
 	{
 		$log->debug("Запрос на становление мастером отвергнут");
 	}
 	else 
 	{
 		$log->error("Получен неизвестный запрос");
 	}

 	&_dbSetRole('slave');

	$socket->close();
	return 0;
}


#метод реализующий логику работы
sub logic 
{
	my ($self) = @_;

	my $subprocess_pid=fork;
	$childrenPid = $subprocess_pid;

	if ($subprocess_pid == 0) {
		while (1) {
			
			my $return_value; # переменная для проверки возвращаемого значения
			# цикличная проверка доступности соседа
			while (1) {
				$return_value = &_checkNeightbour($self->{_neightbour_address}, $self->{_neightbour_port});
				if ($return_value == 0) {
					$log->debug("Удаленный скрипт доступен");
					sleep(10);
				}
				else {
					$log->warn("Удаленный скрипт недоступен");
					last;	#выходим их цикла, переходим к созданию keepalive сервера
				}	
			}
			&_keepaliveServer($self->{_local_address}, $self->{_local_port});
		}
	}
	else {
		$log->info("Процесс $$: создал форк: $subprocess_pid, для общения с другим скриптом");
	}
}

# Метод инициализации конфигурационного файла скрипта и добавление информации о нём в БД.
sub initNewScript
{
	my ($self) = @_;
	print "Сейчас будет выполнена настройка обязательных параметров.\n";
	print color("blue"), "[...] ", color("reset");
	print "Создание директории /etc/voiceng\n";
	if ( -d "/etc/voiceng" ) {
		print color("green"), "[OK] ", color("reset");
		print "Директория /etc/voiceng уже существует\n";
	} else {
		print color("blue"), "[...] ", color("reset");
    	print "Директория не найдена, создаю.\n";
    	unless(mkdir "/etc/voiceng") {    		
			die "[FAILED] Не удалось создать директорию /etc/voiceng\n";
		}
		print color("green"), "[OK] ", color("reset");
		print "Директория /etc/voiceng успешно создана\n";
	}
	print color("blue"), "[...] ", color("reset");
	print "Создание конфигурационного файла /etc/voiceng/${currentScriptName}.ini\n";
	open(CONFFILE, '>', "/etc/voiceng/${currentScriptName}.ini") or die("[FAILED] Не удалось открыть для записи файл /etc/voiceng/${currentScriptName}.ini");
	print CONFFILE "[${currentScriptName}]\n";
	
	print  "Расположение pid файла (по-умолчанию /run/voiceng/${currentScriptName}.pid): ";	
	chomp (my $inputPidFile = <STDIN>);
	$inputPidFile ||= "/run/voiceng/${currentScriptName}.pid";
	print CONFFILE "pid_file=${inputPidFile}\n";

	print  "Рабочая директория (по-умолчанию /usr/local/voiceng/bin): ";	
	chomp (my $inputWorkDir = <STDIN>);
	$inputWorkDir ||= '/usr/local/voiceng/bin';
	print CONFFILE "working_dir=${inputWorkDir}\n";

	my($addr)=inet_ntoa((gethostbyname(hostname))[4]);
	print  "ip-адрес на котором работает балансер (${addr}): ";	
	chomp (my $inputLocalIp = <STDIN>);
	$inputLocalIp ||= "${addr}";
	print CONFFILE "local_address=${inputLocalIp}\n";

	print  "ip-адрес скрипта-соседа: ";	
	chomp (my $inputNeiIp = <STDIN>);
	$inputNeiIp ||= '';
	print CONFFILE "neightbour_address=${inputNeiIp}\n";

	print  "Укажите порт взаимодействия (50XX): ";	
	chomp (my $inputPort = <STDIN>);
	$inputPort ||= '';
	print CONFFILE "local_port=${inputPort}\n";
	print CONFFILE "neightbour_port=${inputPort}\n";
	print color("green"), "[OK] ", color("reset");
	print "Настройки соединения скриптов сохранены\n";

	print  "Настройки соединения с БД: \n";
	print "db_host=10.100.11.106\ndb_user=balancer_user\ndb_password=\n";
	print "Оставить настройки по-умолчанию(Y/n)? : ";	
	chomp (my $inputDBbool = <STDIN>);
	$inputDBbool ||= "y";
	if (($inputDBbool eq 'y') || ($inputDBbool eq 'Y')) {
		print CONFFILE "\ndb_host=10.100.11.106\ndb_user=balancer_user\ndb_password=\n";
	}
	else {
		print  "Укажите хост БД (10.100.11.106): ";	
		chomp (my $inputDBhost = <STDIN>);
		$inputDBhost ||= '10.100.11.106';
		print CONFFILE "db_host=${inputDBhost}\n";

		print  "Укажите пользователя БД (script_user): ";	
		chomp (my $inputDBuser = <STDIN>);
		$inputDBuser ||= 'script_user';
		print CONFFILE "db_user=${inputDBuser}\n";

		print  "Укажите пароль БД (Qwerty): ";	
		chomp (my $inputDBpass = <STDIN>);
		$inputDBpass ||= 'Qwerty';
		print CONFFILE "db_password=${inputDBpass}\n";
	}
	print color("green"), "[OK] ", color("reset");
	print "Настройки соединения скрипта с БД сохранены\n";

	print color("blue"), "[...] ", color("reset");
	print "Добавление информации о скрипте в БД\n";
	print "Введите хост БД: ";
	chomp (my $DBhost = <STDIN>);
	
	print "Введите пользователя: ";
	chomp (my $DBuser = <STDIN>);

	print "Введите пароль: ";
	chomp (my $DBpass = <STDIN>);

	eval
    {
        $dbh = DBI->connect
        (
            "DBI:mysql:voiceng;host=$DBhost", $DBuser, $DBpass,
                {
                    'RaiseError'        => 1,
                    'InactiveDestroy'   => 1,
                }
        );
    };

    if ($@)
    {
		print color("red"), "[FAILED] ", color("reset");
		print "Не удалось подключиться к БД\n";
		return undef;
    }

    $dbh->{mysql_auto_reconnect} = 1;

	#заносим скрипт в таблицу script_dispatcher
	eval {
		my $host = `hostname`;
		chomp($host);
		my $currentTime = strftime('%Y-%m-%d %H:%M:%S',localtime);
		$dbh->do("INSERT INTO scripts_dispatcher(script_name, full_path, node, time_change_role) VALUES(?, ?, ?, ?)", undef, $currentScriptNameWithExtension, $currentDir, $host, $currentTime);		
		print color("green"), "[OK] ", color("reset");
		print "Информация о скрипте успешно добавлена в БД\n";

	};
	if ($@) {
		print color("red"), "[FAILED] ", color("reset");
		print "Не удалось добавить информацию о скрипте в базу!\n";
		$log->error("Не удалось добавить информацию о скрипте в базу!");
		$dbh->disconnect();
		return undef;
	}
	$dbh->disconnect();	
}

1; # End of Voiceng
