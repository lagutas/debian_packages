package Dancer::Continuation::Route::Templated;

use strict;
use warnings;
use Carp;

use base qw(Dancer::Continuation::Route);

1;
